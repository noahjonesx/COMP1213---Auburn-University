
public class ForLoopExample {

   public static void main(String[] args) {
      
      for (double x = 0; x < 100.0; x+=.5) {
         System.out.println(x);   
      }
   }
}