public class AdummyY {

   public static void main(String[] args) {
      String s = "TriangleList2.javaTriangleList2.java";
   
      s = "null";
   }
}